package com.worksap.bootcamp.webeditor.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jndi.JndiTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.worksap.bootcamp.util.StopWatch;
import com.worksap.bootcamp.webeditor.dao.DaoFactory;

@ComponentScan("com.worksap.bootcamp.webeditor")
@Configuration
@EnableWebMvc
@EnableTransactionManagement
public class WebEditorConfig extends WebMvcConfigurerAdapter{
	@Bean
	public StopWatch stopWatch() {
		return new StopWatch();
	}

	
	@Autowired
	@Bean
	@Qualifier("selectedImpl")
	public DaoFactory selectedDaofactory(@Qualifier("daoFactoryJdbcImpl") DaoFactory target) {
		return target;
	}
	
	@Override
    public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
        configurer.enable();
    }
	
	@Bean
    public InternalResourceViewResolver jspViewResolver() {
        InternalResourceViewResolver bean = new InternalResourceViewResolver();
    //    bean.setPrefix("/WEB-INF/jsp");
        return bean;
    }
	
	@Bean
    public DataSource dataSource() throws Exception {  
		JndiTemplate jndi = new JndiTemplate();
        return (DataSource) jndi.lookup("java:comp/env/jdbc/webeditor");
    }
	
	
	@Autowired
    @Bean
    public JdbcTemplate jdbcTemplate(DataSource datasource) throws Exception {
        return new JdbcTemplate(datasource);
    }
	
	@Autowired
    @Bean
    public PlatformTransactionManager transactionManager(DataSource dataSource) throws Exception {
        return new DataSourceTransactionManager(dataSource);
    }
	
	
}
