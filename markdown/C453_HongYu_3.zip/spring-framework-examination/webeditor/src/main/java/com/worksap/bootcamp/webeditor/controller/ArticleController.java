package com.worksap.bootcamp.webeditor.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.worksap.bootcamp.webeditor.entity.ArticleEntity;
import com.worksap.bootcamp.webeditor.entity.ArticleHeaderEntity;
import com.worksap.bootcamp.webeditor.service.ArticleService;
import com.worksap.bootcamp.webeditor.service.ServiceFactory;
import com.worksap.bootcamp.webeditor.service.ServiceFactoryImpl;
import com.worksap.bootcamp.webeditor.vo.ArticleHeaderVo;
import com.worksap.bootcamp.webeditor.vo.ArticleVo;


/**
 * Treat all request for articles.
 * 
 * @author works
 */
@Controller
@RequestMapping(value="/webeditor/article")
public class ArticleController {
	private final ServiceFactory factory;
	private final ArticleService service;


	@Autowired
	public ArticleController(ServiceFactoryImpl factory) {
		this.factory = factory;
		this.service = factory.getArticleService();
	}
	
	/**
	 * Add new article.
	 * (But, client send add request when add button is clicked. 'detail' has many empty fields)
	 * 
	 * @param detail This detail does not have articleId
	 * @return This detail has articleId
	 */
	@RequestMapping(value="/add", method = RequestMethod.POST)
	@ResponseBody
	public ArticleEntity add(@RequestBody ArticleEntity detail) {
		// TODO Auto-generated method stub
		ArticleVo.Builder avb = new ArticleVo.Builder();
		avb.id(detail.getId());
		avb.content(detail.getContent());
		avb.title(detail.getTitle());
		avb.tags(detail.getTags());
		ArticleVo av = avb.build();
		av = service.create(av);
		detail.setId(av.getId());
		ArticleEntity dd = new ArticleEntity();
		return dd;
		
	}


	/**
	 * Want to get article title list.
	 * (Paging is not required.
	 *  Be carefully! client send async request.
	 *  If you use H2 embedded mode, H2 will return error.
	 *  Please use H2 server mode)
	 * 
	 * @return
	 */
	@RequestMapping(value="/load", method = RequestMethod.GET)
	@ResponseBody
	public List<ArticleHeaderEntity> load() {
		// TODO Auto-generated method stub
		List<ArticleHeaderVo> ahvList = service.load();
		List<ArticleHeaderEntity> aheList = new ArrayList();
		ahvList.stream().map(ahv -> new ArticleHeaderEntity(ahv.getId(),ahv.getTitle(),ahv.getTags())).forEach(aheList::add);
	/*
		for(ArticleHeaderVo ahv:ahvList){
			ArticleHeaderEntity ahe = new ArticleHeaderEntity(ahv.getId(),ahv.getTitle(),ahv.getTags());
			aheList.add(ahe);
		}
		*/
		return aheList;
	}
	

	/**
	 * Update article to new one.
	 * Search old one with detail.articleId.
	 * 
	 * @param detail
	 */
	@RequestMapping(value="/put", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	public void put(@RequestBody ArticleEntity detail) {
		// TODO Auto-generated method stub
	//	ArticleEntity detail = new ArticleEntity("100","co3n","tit3",Arrays.asList("2"));
		ArticleVo.Builder avb = new ArticleVo.Builder();
		avb.id(detail.getId());
		avb.content(detail.getContent());
		avb.title(detail.getTitle());
		avb.tags(detail.getTags());
		service.update(avb.build());
	}


	/**
	 * Delete article with articleId
	 * 
	 * @param articleId
	 */
	@RequestMapping(value="/delete/{articleId}", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	public void delete(@PathVariable("articleId") String articleId) {
		// TODO Auto-generated method stub
		service.delete(articleId);
	}


	/**
	 * Get all data with articleId
	 * 
	 * @param articleId
	 * @return
	 */
	
	@RequestMapping(value="/detail/{articleId}", method = RequestMethod.GET)
	@ResponseBody
	public ArticleEntity getDetail(@PathVariable("articleId") String articleId) {
		// TODO Auto-generated method stub
		ArticleVo av = service.find(articleId);
		ArticleEntity ae = new ArticleEntity(av.getId(),av.getContent(),av.getTitle(),av.getTags());
	//	ArticleEntity ae = new ArticleEntity("a","b","v",Arrays.asList("2","2"));
		return ae;
	}
}
