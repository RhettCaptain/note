package com.worksap.bootcamp.webeditor.dao;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.dao.support.DataAccessUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.worksap.bootcamp.webeditor.dto.ArticleDetailDto;
import com.worksap.bootcamp.webeditor.dto.ArticleHeaderDto;
import com.worksap.bootcamp.webeditor.dto.ArticleTagRelationDto;
import com.worksap.bootcamp.webeditor.vo.ArticleHeaderVo;
import com.worksap.bootcamp.webeditor.vo.ArticleVo;

@Component
final class ArticleDaoJdbcImpl implements ArticleDao {
	private static final String SELECT_SQL =
			   "SELECT AH.TITLE, AD.CONTENT"
			+ " FROM ARTICLE_HEADER AH INNER JOIN ARTICLE_DETAIL AD ON AH.ID = AD.ID"
			+ " WHERE AH.ID = ?";

	
	private JdbcTemplate template;
	private ArticleHeaderDaoJdbcImpl artHeaderDao;
	private ArticleDetailDaoJdbcImpl artDetailDao;
	private ArticleTagRelationDaoJdbcImpl artTagRelDao;
	
	@Autowired
	public ArticleDaoJdbcImpl(JdbcTemplate template){
		this.template = template;
		this.artHeaderDao = new ArticleHeaderDaoJdbcImpl(template);
		this.artDetailDao = new ArticleDetailDaoJdbcImpl(template);
		this.artTagRelDao = new ArticleTagRelationDaoJdbcImpl(template);
	}

	@Override
	public void delete(String articleId) {
		// TODO Auto-generated method stub
		ArticleHeaderDto artHeaderDto = new ArticleHeaderDto();
		ArticleDetailDto artDetailDto = new ArticleDetailDto();
		artHeaderDto.setId(articleId);
		artDetailDto.setId(articleId);
		artHeaderDao.delete(artHeaderDto);
		artDetailDao.delete(artDetailDto);
		artTagRelDao.deleteTags(articleId);
		
		/*
		String DEL_HEAD_SQL = "DELETE FROM ARTICLE_HEADER WHERE ID = ?";
		String DEL_DETI_SQL = "DELETE FROM ARTICLE_DETAIL WHERE ID = ?";
		String DEL_RELA_SQL = "DELETE FROM ARTICLE_TAG_RELATION WHERE ARTICLE_ID = ?";
		template.update(DEL_HEAD_SQL,
				ps -> ps.setString(1, articleId));
		template.update(DEL_DETI_SQL,
				ps -> ps.setString(1, articleId));
		template.update(DEL_RELA_SQL,
				ps -> ps.setString(1, articleId));
		 */
	}


	@Override
	public ArticleVo find(String articleId) {
		// TODO Auto-generated method stub
		/*
		List<ArticleVo>	test	= template.query(SELECT_SQL,
						ps -> ps.setString(1,articleId),
						(rs,rowNum) -> {
							ArticleVo.Builder avBuilder = new ArticleVo.Builder();
							avBuilder.id(articleId);
							avBuilder.title(rs.getString(1));
							avBuilder.content(rs.getString(2));
							//avBuilder.tags(tags);
							return avBuilder.build();
						});
		return test.get(0);
		*/
		
	//	try{
			String FIND_TAGS_SQL = "SELECT AR.TAG_ID FROM ARTICLE_TAG_RELATION AR  WHERE AR.ARTICLE_ID = ?";
			List<String> tags = template.query(FIND_TAGS_SQL,
					ps -> ps.setString(1,articleId),
					(rs,rowNum) -> new String(rs.getString(1)));
			
			String FIND_ART_VO_SQL = "SELECT AH.TITLE, AD.CONTENT"
					+ " FROM ARTICLE_HEADER AH INNER JOIN ARTICLE_DETAIL AD ON AH.ID = AD.ID"
					+ " WHERE AH.ID = ?";
			List<ArticleVo> avList = template.query(FIND_ART_VO_SQL,
					ps -> ps.setString(1,articleId),
					(rs,rowNum) -> {
						ArticleVo.Builder avBuilder = new ArticleVo.Builder();
						avBuilder.id(articleId);
						avBuilder.title(rs.getString(1));
						avBuilder.content(rs.getString(2));
						avBuilder.tags(tags);
						return avBuilder.build();
					});
			if(avList.size() == 0){
				return null;
			}else{
				return avList.get(0);
			}
	/*	}catch(Exception e){
			System.out.println("find articleVo err");
			System.out.println(e.getMessage());
			return null;
		}*/
		
	}


	@Override
	public String generateNewId() {
		// TODO Auto-generated method stub
		String FIND_ID_SQL = "SELECT ID FROM ARTICLE_HEADER ORDER BY ID";
		List<String> idStrList = template.queryForList(FIND_ID_SQL, String.class);
		List<Integer> idIntList = new ArrayList();
		for(String idStr:idStrList){
			idIntList.add(Integer.parseInt(idStr));
		}
		idIntList.sort(Comparator.naturalOrder());
		Integer id = 0;
		for(Integer idInt:idIntList){
			if(id == idInt){
				id++;
			}else{
				break;
			}
		}
		return id.toString();
	}


	@Override
	public void insert(ArticleVo newRecord) {
		String id = newRecord.getId();
		String title = newRecord.getTitle();
		String content = newRecord.getContent();
		List<String> tags = newRecord.getTags();
		ArticleDetailDto add = new ArticleDetailDto(id,content);
		ArticleHeaderDto ahd = new ArticleHeaderDto(id,title);
		
		artDetailDao.insert(add);
		artHeaderDao.insert(ahd);
		artTagRelDao.deleteTags(id);
		artTagRelDao.addTags(id, tags);
		
		/*
		String id = newRecord.getId();
		String title = newRecord.getTitle();
		String content = newRecord.getContent();
		List<String> tags = newRecord.getTags();
		
		String INSERT_AD_SQL = "INSERT INTO ARTICLE_DETAIL (ID,CONTENT) VALUES (?,?)";
		template.update(INSERT_AD_SQL,
				ps -> {
					ps.setString(1, id);
					ps.setString(2, content);
				});
		String INSERT_AH_SQL = "INSERT INTO ARTICLE_HEADER (ID,TITLE) VALUES (?,?)";
		template.update(INSERT_AH_SQL,
				ps -> {
					ps.setString(1, id);
					ps.setString(2, title);
				});
		String INSERT_ATR_SQL = "INSERT INTO ARTICLE_TAG_RELATION (ARTICLE_ID,TAG_ID) VALUES (?,?)";
		String FIND_TAGID_SQL = "SELECT ID FROM ARTICLE_TAG WHERE NAME = ?";
		for(String s:tags){
			if(s == null || s == ""){
				continue;
			}
			try{
			String  tagId = DataAccessUtils.requiredSingleResult(
					template.query(FIND_TAGID_SQL, 
							ps -> ps.setString(1,s),
							(rs,rowNum) -> new String(rs.getString(1)))
					);
			template.update(INSERT_ATR_SQL,
					ps -> {
						ps.setString(1, id);
						ps.setString(2, tagId);
					});
			}catch(Exception e){
				System.out.println("no such tag");
			}
		}
		*/
		
		// TODO Auto-generated method stub
	}


	@Override
	public Iterator<ArticleHeaderVo> list() {
		// TODO Auto-generated method stub
		
		List<ArticleHeaderDto> ahdList =  artHeaderDao.list();
		List<ArticleHeaderVo> ahvList = new ArrayList();
		ahdList.stream().map(ahd -> {
			ArticleHeaderVo.Builder ahvb = new ArticleHeaderVo.Builder();
			ahvb.id(ahd.getId());
			ahvb.title(ahd.getTitle());
			ahvb.tags(artTagRelDao.listForArticle(ahd.getId()));
			return ahvb.build();
		}).forEach(ahvList::add);
		/*
		for(ArticleHeaderDto ahd:ahdList){
			ArticleHeaderVo.Builder ahvb = new ArticleHeaderVo.Builder();
			ahvb.id(ahd.getId());
			ahvb.title(ahd.getTitle());
			ahvb.tags(artTagRelDao.listForArticle(ahd.getId()));
			ArticleHeaderVo ahv = ahvb.build();
			ahvList.add(ahv);
		}*/
		return ahvList.iterator();
		/*
		String FIND_AH_SQL = "SELECT * FROM ARTICLE_HEADER";
		String FIND_TAGS_SQL = "SELECT NAME FROM ARTICLE_TAG_RELATION AR INNER JOIN ARTICLE_TAG AT ON AT.ID = AR.TAG_ID WHERE AR.ARTICLE_ID = ?";
		
		try{
		return template.query(FIND_AH_SQL, 
				(rs,rowNum) -> {
					ArticleHeaderVo.Builder ahb = new ArticleHeaderVo.Builder();
					ahb.id(rs.getString(1));
					ahb.title(rs.getString(2));
					
					List<String> tags = template.query(FIND_TAGS_SQL,
							psIn -> psIn.setString(1,rs.getString(1)),
							(rsIn,rowNumIn) -> new String(rsIn.getString(1)));
					
					ahb.tags(tags);
					ArticleHeaderVo ahv = ahb.build();
					return ahv;
				}).iterator();
		}catch(Exception e){
			System.out.println("list err");
			return null;
		}*/
	}


	@Override
	public void update(ArticleVo newRecord) {
		// TODO Auto-generated method stub
		String id = newRecord.getId();
		String title = newRecord.getTitle();
		String content = newRecord.getContent();
		List<String> tags = newRecord.getTags();
		ArticleDetailDto adDto = new ArticleDetailDto(id,content);
		ArticleHeaderDto ahDto = new ArticleHeaderDto(id,title);
		
		artHeaderDao.update(ahDto);
		artDetailDao.update(adDto);
		artTagRelDao.deleteTags(id);
		artTagRelDao.addTags(id, tags);
		
		/*
		String id = newRecord.getId();
		String title = newRecord.getTitle();
		String content = newRecord.getContent();
		List<String> tags = newRecord.getTags();
		
		try{
		String UPDATE_AD_SQL = "UPDATE ARTICLE_DETAIL SET CONTENT = ? WHERE ID = ?";
		template.update(UPDATE_AD_SQL,
				ps -> {
					ps.setString(1, content);
					ps.setString(2, id);
				});
		String UPDATE_AH_SQL = "UPDATE ARTICLE_HEADER SET TITLE = ? WHERE ID = ?";
		template.update(UPDATE_AH_SQL,
				ps -> {
					ps.setString(1, title);
					ps.setString(2, id);
				});
		String UPDATE_ATR_SQL = "UPDATE ARTICLE_TAG_RELATION SET TAG_ID = ? WHERE ARTICLE_ID = ?";
		String FIND_TAGID_SQL = "SELECT ID FROM ARTICLE_TAG WHERE NAME = ?";
		for(String s:tags){
			if(s == null || s == ""){
				continue;
			}
			String tagId = DataAccessUtils.requiredSingleResult(
					template.query(FIND_TAGID_SQL, 
							ps -> ps.setString(1,s),
							(rs,rowNum) -> new String(rs.getString(1)))
					);
			template.update(UPDATE_ATR_SQL,
					ps -> {
						ps.setString(1, tagId);
						ps.setString(2, id);
					});
		}
		}catch(Exception e){
			System.out.println("update err");
			
		}
		*/
	}
}
