package com.worksap.bootcamp.webeditor.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.worksap.bootcamp.webeditor.dto.ArticleDetailDto;


final class ArticleDetailDaoJdbcImpl {
	private static final String DELETE_SQL = "DELETE FROM ARTICLE_DETAIL WHERE ID = ?";
	private static final String INSERT_SQL = "INSERT INTO ARTICLE_DETAIL(ID, CONTENT) VALUES (?, ?)";
	private static final String UPDATE_SQL = "UPDATE ARTICLE_DETAIL SET CONTENT = ? WHERE ID = ?";

	private JdbcTemplate template;
	
	@Autowired
	public ArticleDetailDaoJdbcImpl(JdbcTemplate template){
		this.template = template;
	}
	
	void delete(ArticleDetailDto record) {
		// TODO Implement it!
		template.update(DELETE_SQL,
				ps -> ps.setString(1, record.getId()));
	}


	void insert(ArticleDetailDto newRecord) {
		// TODO Implement it!
		template.update(INSERT_SQL,
				ps -> {
					ps.setString(1, newRecord.getId());
					ps.setString(2, newRecord.getContent());
				});
	}


	void update(ArticleDetailDto newRecord) {
		// TODO Implement it!
		template.update(UPDATE_SQL,
				ps -> {
					ps.setString(1, newRecord.getContent());
					ps.setString(2, newRecord.getId());;
				});
	}
}
