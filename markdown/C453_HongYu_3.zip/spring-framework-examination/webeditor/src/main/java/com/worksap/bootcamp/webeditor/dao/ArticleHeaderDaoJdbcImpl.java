package com.worksap.bootcamp.webeditor.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.worksap.bootcamp.webeditor.dto.ArticleHeaderDto;

@Component
final class ArticleHeaderDaoJdbcImpl {
	private static final String DELETE_SQL = "DELETE FROM ARTICLE_HEADER WHERE ID = ?";
	private static final String INSERT_SQL = "INSERT INTO ARTICLE_HEADER(ID, TITLE) VALUES (?, ?)";
	private static final String LIST_SQL = "SELECT ID, TITLE FROM ARTICLE_HEADER ORDER BY ID";
	private static final String UPDATE_SQL = "UPDATE ARTICLE_HEADER SET TITLE = ? WHERE ID = ?";

	private JdbcTemplate template;
	
	@Autowired
	public ArticleHeaderDaoJdbcImpl(JdbcTemplate template){
		this.template = template;
	}

	void delete(ArticleHeaderDto record) {
		// TODO Implement it!
		template.update(DELETE_SQL,
				ps -> ps.setString(1, record.getId()));
	}


	void insert(ArticleHeaderDto newRecord) {
		// TODO Implement it!
		template.update(INSERT_SQL,
				ps -> {
					ps.setString(1, newRecord.getId());
					ps.setString(2,newRecord.getTitle());
				});
	}


	List<ArticleHeaderDto> list() {
		// TODO Implement it!
		return template.query(LIST_SQL,
				(rs,rowNum) -> new ArticleHeaderDto(rs.getString(1),rs.getString(2)));
	}


	void update(ArticleHeaderDto newRecord) {
		// TODO Implement it!
		template.update(UPDATE_SQL,
				ps -> {
					ps.setString(1, newRecord.getTitle());
					ps.setString(2, newRecord.getId());
				});
	}
}
