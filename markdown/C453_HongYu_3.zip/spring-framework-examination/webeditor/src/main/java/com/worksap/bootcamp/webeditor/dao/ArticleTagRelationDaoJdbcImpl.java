package com.worksap.bootcamp.webeditor.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.worksap.bootcamp.webeditor.dto.ArticleTagRelationDto;


final class ArticleTagRelationDaoJdbcImpl {
	private static final String DELETE_SQL = "DELETE ARTICLE_TAG_RELATION WHERE ARTICLE_ID = ?";
	private static final String INSERT_SQL = "INSERT INTO ARTICLE_TAG_RELATION(ARTICLE_ID, TAG_ID) VALUES (?, ?)";
	private static final String LIST_SQL = "SELECT ARTICLE_ID, TAG_ID FROM ARTICLE_TAG_RELATION ORDER BY ARTICLE_ID";
	private static final String LIST_FOR_ARTICLE_SQL = "SELECT TAG_ID FROM ARTICLE_TAG_RELATION WHERE ARTICLE_ID = ?";

	private JdbcTemplate template;

	@Autowired
	public ArticleTagRelationDaoJdbcImpl(JdbcTemplate template){
		this.template = template;
	}
	
	void addTags(String articleId, List<String> tags) {
		// TODO Auto-generated method stub
		tags.stream().map(tag->template.update(INSERT_SQL,
					ps -> {
						ps.setString(1, articleId);
						ps.setString(2, tag);
					}));
		/*
		for(String tag:tags){
			template.update(INSERT_SQL,
					ps -> {
						ps.setString(1, articleId);
						ps.setString(2, tag);
					});
		}
		*/
	}


	void deleteTags(String articleId) {
		// TODO Auto-generated method stub
		template.update(DELETE_SQL,
				ps -> ps.setString(1, articleId));
	}


	List<ArticleTagRelationDto> list() {
		// TODO Auto-generated method stub
		return template.query(LIST_SQL,
				(rs,rowNum) -> new ArticleTagRelationDto(rs.getString(1),rs.getString(2)));
	}


	List<String> listForArticle(String articleId) {
		// TODO Auto-generated method stub
		return template.query(LIST_FOR_ARTICLE_SQL, 
				ps -> ps.setString(1,articleId),
				(rs,rowNum) -> new String(rs.getString(1)));
	}
}
