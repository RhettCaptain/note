package com.worksap.bootcamp.webeditor.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.worksap.bootcamp.webeditor.dao.ArticleDao;
import com.worksap.bootcamp.webeditor.dao.DaoFactory;
import com.worksap.bootcamp.webeditor.vo.ArticleHeaderVo;
import com.worksap.bootcamp.webeditor.vo.ArticleVo;

@Component
class ArticleServiceImpl implements ArticleService {
	private ArticleDao artDao;
	
	@Autowired
	public ArticleServiceImpl(@Qualifier("selectedImpl") DaoFactory factory){
		this.artDao = factory.getArticleDao();
	}
	
	@Override
	@Transactional
	public ArticleVo create(ArticleVo newRecord) {
		// TODO Auto-generated method stub
		ArticleVo.Builder avb = new ArticleVo.Builder();
		avb.id(artDao.generateNewId());
		avb.content(newRecord.getContent());
		avb.title(newRecord.getTitle());
		avb.tags(newRecord.getTags());
		ArticleVo av = avb.build();
		artDao.insert(av);
		return av;
	}


	@Override
	@Transactional
	public void delete(String articleId) {
		// TODO Auto-generated method stub
		artDao.delete(articleId);
	}


	@Override
	public ArticleVo find(String articleId) {
		// TODO Auto-generated method stub
		return artDao.find(articleId);
	}


	@Override
	public List<ArticleHeaderVo> load() {
		// TODO Auto-generated method stub
		Iterator<ArticleHeaderVo> it = artDao.list();
		List<ArticleHeaderVo> ahvList = new ArrayList();
		while(it.hasNext()){
			ahvList.add(it.next());
		}
		return ahvList;
	}


	@Override
	@Transactional
	public void update(ArticleVo newRecord) {
		// TODO Auto-generated method stub
		artDao.update(newRecord);
	}
}
