package com.worksap.bootcamp.webeditor.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.worksap.bootcamp.webeditor.dao.DaoFactory;

@Component
public class ServiceFactoryImpl implements ServiceFactory {
	
	
	private DaoFactory factory;
	private ArticleService artService;
	private TagService tagService;
	
	public ServiceFactoryImpl(){
	}
	
	@Autowired
	public ServiceFactoryImpl(@Qualifier("selectedImpl") DaoFactory factory,
			ArticleService artService,TagService tagService){
		this.factory = factory;
		this.artService = artService;
		this.tagService = tagService;
	}
	
	@Override
	public ArticleService getArticleService() {
		// TODO Auto-generated method stub
		return artService;
	}


	@Override
	public TagService getTagService() {
		// TODO Auto-generated method stub
		return tagService;
	}
}
