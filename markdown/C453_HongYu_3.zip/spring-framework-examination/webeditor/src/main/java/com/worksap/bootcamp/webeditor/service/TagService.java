package com.worksap.bootcamp.webeditor.service;

import java.util.List;

import com.worksap.bootcamp.webeditor.vo.TagVo;

public interface TagService {
	List<TagVo> load();
}
