package com.worksap.bootcamp.webeditor.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.worksap.bootcamp.webeditor.dao.DaoFactory;
import com.worksap.bootcamp.webeditor.dao.TagDao;
import com.worksap.bootcamp.webeditor.dto.TagDto;
import com.worksap.bootcamp.webeditor.vo.TagVo;

@Component
class TagServiceImpl implements TagService {
	private TagDao tagDao;


	/*
	 * Use constructor injection make test simple
	 */
	@Autowired
	public TagServiceImpl(@Qualifier("selectedImpl") DaoFactory factory) {
		this.tagDao = factory.getTagDao();
	}


	@Override
	public List<TagVo> load() {
		// TODO Auto-generated method stub
		Iterator<TagDto> it = tagDao.list();
		List<TagVo> tvList = new ArrayList();
		while(it.hasNext()){
			TagDto td = it.next();
			TagVo.Builder tvb = new TagVo.Builder();
			tvb.id(td.getId());
			tvb.name(td.getName());
			TagVo tv = tvb.build();
			tvList.add(tv);
		}
		return tvList;
	}
}
