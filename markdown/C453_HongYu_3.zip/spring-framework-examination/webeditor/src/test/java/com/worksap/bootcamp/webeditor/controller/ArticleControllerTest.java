package com.worksap.bootcamp.webeditor.controller;

import static org.junit.Assert.fail;

import org.junit.Test;


public class ArticleControllerTest {
	@Test
	public void testAdd() throws Exception {
		fail("Not yet implemented");
	}


	@Test
	public void testLoad() throws Exception {
		fail("Not yet implemented");
	}


	@Test
	public void testPut() throws Exception {
		fail("Not yet implemented");
	}


	@Test
	public void testDelete() throws Exception {
		fail("Not yet implemented");
	}


	@Test
	public void testGetDetail() throws Exception {
		fail("Not yet implemented");
	}


	@Test
	public void testForbiddenUrl() throws Exception {
		fail("Not yet implemented");
	}
}
