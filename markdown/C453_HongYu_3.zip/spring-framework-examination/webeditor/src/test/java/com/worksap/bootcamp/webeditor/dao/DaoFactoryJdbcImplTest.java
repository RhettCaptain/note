package com.worksap.bootcamp.webeditor.dao;

import static org.junit.Assert.*;

import org.junit.Test;


public class DaoFactoryJdbcImplTest {
	@Test
	public void testGetArticleDao() {
		fail("Not yet implemented");
	}


	@Test
	public void testGetTagDao() {
		fail("Not yet implemented");
	}
}
