package com.worksap.bootcamp.webeditor.service;

import static org.junit.Assert.*;

import org.junit.Test;


public class ArticleServiceImplTest {
	@Test
	public void testCreate() {
		fail("Not yet implemented");
	}


	@Test
	public void testDelete() {
		fail("Not yet implemented");
	}


	@Test
	public void testFind() {
		fail("Not yet implemented");
	}


	@Test
	public void testLoad() {
		fail("Not yet implemented");
	}


	@Test
	public void testUpdate() {
		fail("Not yet implemented");
	}
}
